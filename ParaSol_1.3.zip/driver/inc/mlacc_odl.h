/*****************************************************************************

 Copyright (C) 2024 ROHM Co., Ltd.
 All rights reserved.

 This software is provided "as is" and any expressed or implied
 warranties, including, but not limited to, the implied warranties of
 merchantability and fitness for a particular purpose are disclaimed.
 ROHM shall not be liable for any direct, indirect, consequential or
 incidental damages arising from using or modifying this software.
 You (customer) can modify and use this software in whole or part on
 your own responsibility, only for the purpose of developing the software
 for use with microcontroller manufactured by ROHM.

******************************************************************************/
/** \file
 *
 *   \brief   On-Device Learning library.
 */
#ifndef MLACC_ODL_H__
#define MLACC_ODL_H__

#include <stdint.h>
#include <stdbool.h>

/*############################################################################*/
/*#                                  Macro                                   #*/
/*############################################################################*/

/*=== API parameters value ===*/
/* Activation functions */
#define	ODL_ACTV_LINEAR       ( 0U )            /**< Linear f(x) = x               */
#define	ODL_ACTV_SIGMOID      ( 1U )            /**< Hard Sigmoid function         */
#define	ODL_ACTV_RELU         ( 2U )            /**< ReLU (Ramp) function          */
#define	ODL_ACTV_TANH         ( 3U )            /**< Hard tanh function            */

/* Loss functions */
#define	ODL_LOSS_MAE          ( 0U )            /**< Mean absolute error           */
#define	ODL_LOSS_MSE          ( 1U )            /**< Mean squared error            */

/* typedef */
typedef int16_t bfloat16;                       /**< bfloat16 Type                  */

/**
 * \brief Parameters for On-Device Learning
 *
 */
typedef struct ODL_Parameters_t
{
    uint16_t inputSize;                         /**< Number of input nodes         */
    uint16_t hiddenSize;                        /**< Number of hidden nodes        */
    uint16_t outputSize;                        /**< Number of output nodes        */

    bfloat16 forgettingFactor;                  /**< Forgetting factor (bfloat16)  */
    uint8_t activationFunction;                 /**< Activation function           */
    uint8_t lossFunction;                       /**< Loss function                 */
    uint16_t seed;                              /**< Seed of weight Alpha (& Gamma) to generate random number */
    bfloat16 scaleAlpha;                        /**< Weight alpha is generated in [-scaleAlpha, scaleAlpha] */
    bfloat16 scaleGamma;                        /**< Weight gamma (from hidden layer to hidden layer on ESN) is generated in [-scaleGamma, scaleGamma]. (scaleGamma=0) means the model is just a 3-layer neaural network. */
    bfloat16 leakRate;                          /**< Leak rate in ESN */
    bfloat16 l2Param;                           /**< L2 regularization */
}
ODL_Parameters;

/*############################################################################*/
/*#                                  API                                     #*/
/*############################################################################*/
#ifdef  __cplusplus
extern "C" {
#endif //  __cplusplus

/**
 * \name Solist-AI Library related.
 *
 * \{
 */

/**
 * Set the number of AI models to use.
 *
 * \param[in]   modelCount  Model count.
 * \return      Result
 */
bool ODL_SetModelCount(uint8_t modelCount);

/**
 * Initialize AI model.
 *
 * Call this function in order of the lowest value of the instance.
 * If you call this function with instance=1 and then call this function with instance=0, the AI model with instance=1 will not work properly.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   parameters       Parameters.
 * \return      Result
 */
bool ODL_Initialize(uint8_t instance, const ODL_Parameters* parameters);

/**
 *  Reset training.
 *
 * \param[in]   instance         Index of AI model.
 * \return      None
 */
void ODL_Reset(uint8_t instance);

/**
 *  Get paramters.
 *
 * \param[in]   instance         Index of AI model.
 * \return      Current parameters of AI model.
 */
const ODL_Parameters* ODL_GetParameters(uint8_t instance);

/**
 *  Reset the reservoir state (hidden layer) to zero.
 *
 * \param[in]   instance         Index of AI model.
 */
void ODL_ResetReservoir(uint8_t instance);

/**
 *  Get reservoir state.
 *
 * \param[in]   instance        Index of AI model.
 * \param[out]  state           Reservoir state.
 */
void ODL_GetReservoir(uint8_t instance, bfloat16* state);

/**
 *  Set reservoir state.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   state            Reservoir state.
 */
void ODL_SetReservoir(uint8_t instance, const bfloat16* state);

/**
 * Convert fixed-point to bfloat16.
 *
 * \param[out]  y                Output buffer (bfloat16).
 * \param[in]   x                Input buffer (Fixed point).
 * \param[in]   qFormat          Specify fixed-point format of x. For example, qFormat = 12 means Q12 or Q3.12. (5.5 is 0b101.1000 0000 0000 in Q12).
 * \param[in]   size             Size of buffer.
 * \return      None
*/
void ODL_ToBfloat16(bfloat16* y, const int16_t* x, uint8_t qFormat, uint16_t size);

/**
 * Convert bfloat16 to fixed-point.
 *
 * \param[out]  y                Output buffer (Fixed point).
 * \param[in]   x                Input buffer (bfloat16).
 * \param[in]   qFormat          Specify fixed-point format of y. For example, qFormat = 12 means Q12 or Q3.12. (5.5 is 0b101.1000 0000 0000 in Q12).
 * \param[in]   size             Size of buffer.
*/
void ODL_Bfloat16ToFixed(int16_t* y, const bfloat16* x, uint8_t qFormat, uint16_t size);

/**
 * Generate random numbers.
 *
 * \param[out]  y                Output buffer (bfloat16).
 * \param[in]   size             Number of random number generated.
 * \param[in]   seed             Seed of random number generator.
 * \return      None
*/
void ODL_GenerateRandomNumber(bfloat16* y, uint16_t size, uint16_t seed);

/**
 * Start sequential training.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   x                Buffer of input data. NULL means input data has been already filled by DMA.
 * \param[in]   t                Buffer of expected data. x is used for expected data if t == NULL.
 * \return      None
*/
void ODL_StartTrain(uint8_t instance, const bfloat16 *x, const bfloat16 *t);

/**
 * Start prediction.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   x                Buffer of input data. NULL means input data has been already filled by DMA.
 * \param[in]   t                Buffer of expected data to compute loss. It is optional for supervised learning. x is used for expected data if t == NULL.
 * \return      None
*/
void ODL_StartPredict(uint8_t instance, const bfloat16 *x, const bfloat16 *t);

/**
 * Is ODL busy?
 *
 * \param       - 
 * \retval      0                Not busy.
 * \retval      "other than 0"   Busy.
 */
bool ODL_IsBusy(void);

/**
 * Get ODL result.
 *
 * \param[in]   instance         Index of AI model.
 * \param[out]  y                Output buffer.
 * \return      None
 */
void ODL_GetResult(uint8_t instance, bfloat16 *y);

/**
 * Get loss.
 *
 * Learning error during learning.
 * Prediction error during prediction.
 *
 * \param[in]   instance         Index of AI model.
 * \return      Value of loss.
 */
bfloat16 ODL_GetLoss(uint8_t instance);

#if !defined(__MATISSE__)

/**
 * Get loss as a float.
 *
 * Learning error during learning.
 * Prediction error during prediction.
 *
 * \param[in]   instance         Index of AI model.
 * \return      Value of loss.
 */
float ODL_GetLossAsFloat(uint8_t instance);

/**
 * Convert bfloat16 to float.
 *
 * \param[out]  y                Output buffer (float).
 * \param[in]   x                Input buffer (bfloat16).
 * \param[in]   size             Size of buffer.
*/
void ODL_Bfloat16ToFloat(float* y, const bfloat16* x, uint16_t size);

#endif

/**
 * Set weight data (Beta).
 *
 * \param[in]   beta           Buffer of weight data to write.
 * \param[in]   instance       Index of AI model.
 * \param[in]   offset         Offset from the start address of the instance.
 * \param[in]   size           Write size.
 * \return      None
 */
void ODL_SetWeightBeta(const void* beta, uint8_t instance, uint32_t offset, uint16_t size);

/**
 * Set weight data (P).
 *
 * \param[in]   p              Buffer of weight data to write.
 * \param[in]   instance       Index of AI model.
 * \param[in]   offset         Offset from the start address of the instance.
 * \param[in]   size           Write size.
 * \return      None
 */
void ODL_SetWeightP(const void* p, uint8_t instance, uint32_t offset, uint16_t size);

#ifdef ODL_DISABLE_RAND_GENERATOR_ALPHA
/**
 * Set weight data (Alpha).
 *
 * \param[in]   alpha          Buffer of weight data to write.
 * \param[in]   offset         Offset from the start address of weight data.
 * \param[in]   size           Write size.
 */
void ODL_SetWeightAlpha(const void* alpha, uint32_t offset, uint16_t size);

#endif

#ifdef ODL_DISABLE_RAND_GENERATOR_GAMMA
/**
 * Set weight data (Gamma).
 *
 * \param[in]   gamma          Buffer of weight data to write.
 * \param[in]   offset         Offset from the start address of weight data.
 * \param[in]   size           Write size.
 */
void ODL_SetWeightGamma(const void* gamma, uint32_t offset, uint16_t size);

#endif

/**
 * Get weight data (Beta) after training.
 *
 * \param[out]  beta           Buffer of weight data to read.
 * \param[in]   instance       Index of AI model.
 * \param[in]   offset         Offset from the start address of the instance.
 * \param[in]   size           Read size.
 * \return      None
 */
void ODL_GetWeightBeta(void* beta, uint8_t instance, uint32_t offset, uint16_t size);

/**
 * Get weight data (P) after training.
 *
 * \param[out]  p              Buffer of weight data to read.
 * \param[in]   instance       Index of AI model.
 * \param[in]   offset         Offset from the start address of the instance.
 * \param[in]   size           Read size.
 * \return      None
 */
void ODL_GetWeightP(void* p, uint8_t instance, uint32_t offset, uint16_t size);


/* DMA related function prototypes */

/**
 * Get address of input data to AI accelerator for DMA.
 *
 * \return Address of input data.
 */
uint32_t ODL_GetInputAddress(void);

/**
 * Get address of output data to AI accelerator for DMA.
 *
 * \return Address of output data.
 */
uint32_t ODL_GetOutputAddress(void);


/* OSUAD (Online Sequential learning Unsupervised Anomaly Detector) function prototypes */

/**
 *  Reset training.
 *
 * \return      None
 */
void OSUAD_Reset(void);

/**
 * Initialize AI models.
 *
 * \param[in]   parameters       Parameters.
 * \param[in]   numberOfInstance Number of AI models.
 * \return      Result
 */
bool OSUAD_Initialize(const ODL_Parameters* parameters, uint8_t numberOfInstance);

/**
 *  Get the minimum value among the loss of valid models.
 *
 * Learning error during learning.
 * Prediction error during prediction.
 *
 * \param       -
 *  \return     Value of loss.
 */
bfloat16 OSUAD_GetLoss(void);

/**
 * Start prediction.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   x                Buffer of input data.
 * \return      None
*/
#define OSUAD_StartPredict(instance, x) ODL_StartPredict(instance, (x), (x))

/**
 * Start sequential training.
 *
 * \param[in]   instance         Index of AI model.
 * \param[in]   x                Buffer of input data.
 * \return      None
*/
#define OSUAD_StartTrain(instance, x) ODL_StartTrain(instance, (x), (x))



/** \}*/

#ifdef  __cplusplus
}
#endif //  __cplusplus

#endif /* MLACC_ODL_H__ */
