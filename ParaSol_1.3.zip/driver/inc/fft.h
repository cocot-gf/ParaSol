/*****************************************************************************

 Copyright (C) 2024 ROHM Co., Ltd.
 All rights reserved.

 This software is provided "as is" and any expressed or implied
 warranties, including, but not limited to, the implied warranties of
 merchantability and fitness for a particular purpose are disclaimed.
 ROHM shall not be liable for any direct, indirect, consequential or
 incidental damages arising from using or modifying this software.
 You (customer) can modify and use this software in whole or part on
 your own responsibility, only for the purpose of developing the software
 for use with microcontroller manufactured by ROHM.

******************************************************************************/
/** \file
 *
 *   \brief   FFT library.
 */
#ifndef MLACC_FFT_H__
#define MLACC_FFT_H__

#include <stdint.h>
#include <stdbool.h>

/*############################################################################*/
/*#                                  Macro                                   #*/
/*############################################################################*/

/* typedef */
typedef int16_t fft_t;                          /**< FFT Data Type                  */

/** FFT window function */
typedef enum FftWindow_t
{
    FFT_WINDOW_NONE,                            /**< No window functions           */
    FFT_WINDOW_HANN                             /**< Hanning Window Function       */
}
FftWindow;

/*############################################################################*/
/*#                                  API                                     #*/
/*############################################################################*/
#ifdef  __cplusplus
extern "C" {
#endif //  __cplusplus

/**
 * \name Solist-AI Library related
 *
 * \{
 */

/**
 * Build sequence for FFT.
 *
 * \param[in]   size             Input size of FFT (N). size must be a power of 2 and less than or equal to 2048.
 * \param[in]   window           Window function.
 * \return      None
 */
void fft_Init(uint16_t size, FftWindow window);

/**
 * Start fast fourier transform.
 *
 * \param[in]   x                Input buffer (bfloat16). NULL means input data has been already filled by DMA.
 * \param[in]   size             Input size of FFT (N). size must be a power of 2 and less than or equal to 2048.
 * \return      None
 */
void fft_Start(const fft_t x[], uint16_t size);

/**
 * Is FFT busy?
 *
 * \param       - 
 * \retval      0                Not busy
 * \retval      "other than 0"   Busy
 */
bool fft_IsBusy(void);

/**
 * Get FFT result in Single-Sided Amplitude Spectrum.
 *
 * \param[out]  yout             Output buffer (bfloat16)
 * \param[in]   size             Size of output buffer (N/2+1)
 * \return      None
 */
void fft_GetResult(fft_t yout[], uint16_t size);



/** \}*/

#ifdef  __cplusplus
}
#endif //  __cplusplus

#endif // MLACC_FFT_H__
