/*****************************************************************************

 Copyright (C) 2024 ROHM Co., Ltd.
 All rights reserved.

 This software is provided "as is" and any expressed or implied
 warranties, including, but not limited to, the implied warranties of
 merchantability and fitness for a particular purpose are disclaimed.
 ROHM shall not be liable for any direct, indirect, consequential or
 incidental damages arising from using or modifying this software.
 You (customer) can modify and use this software in whole or part on
 your own responsibility, only for the purpose of developing the software
 for use with microcontroller manufactured by ROHM.

 History
    2026.03.04 Ver 1.3.1

******************************************************************************/
/**
 * \file
 *
 * This module is 'Solist-AI' drivers.
 *
 */
/**
 *  \addtogroup driver
 *  \{
 *
 *  \defgroup Solist-AI
 *  \{
 *
 *  \brief Solist-AI Library
 *
 */

#ifndef SOLIST_AI_H__
#define SOLIST_AI_H__

#include <stdint.h>

#include "mlacc.h"
#include "fft.h"
#include "mlacc_odl.h"

/**
 * \name Solist-AI Library related
 *
 * \{
 */

/**
 * Get a version of Solist-AI library.
 *
 * \return      Version
 */
uint16_t SolistAi_GetVersion(void);


/** \}*/

#endif /* SOLIST_AI_H__ */

/** \} */
/** \} */
