/*****************************************************************************

 Copyright (C) 2024 ROHM Co., Ltd.
 All rights reserved.

 This software is provided "as is" and any expressed or implied
 warranties, including, but not limited to, the implied warranties of
 merchantability and fitness for a particular purpose are disclaimed.
 ROHM shall not be liable for any direct, indirect, consequential or
 incidental damages arising from using or modifying this software.
 You (customer) can modify and use this software in whole or part on
 your own responsibility, only for the purpose of developing the software
 for use with microcontroller manufactured by ROHM.

******************************************************************************/
/** \file
 *
 *   \brief   AI accelerator driver.
 */
#ifndef MLACC_H__
#define MLACC_H__

/*############################################################################*/
/*#                                  API                                     #*/
/*############################################################################*/
#ifdef  __cplusplus
extern "C" {
#endif //  __cplusplus

/**
 * \name Solist-AI Common
 *
 * \{
 */

/**
 * Clear AI-RAM
 *
 * \param       -
 * \return      None
 */
void ML_ACC_ClearRAM(void);

/**
 * Enable interrupt
 *
 * \param       -
 * \return      None
 */
void ML_ACC_EnableInterrupt(void);

/**
 * Disable interrupt
 *
 * \param       -
 * \return      None
 */
void ML_ACC_DisableInterrupt(void);

/**
 * Clear interrupt
 *
 * \param       -
 * \return      None
 */
void ML_ACC_ClearInterrupt(void);

/**
 * Protect AI memory
 */
void ML_ACC_ProtectMemory(void);

/**
 * Unprotect AI memory
 */
void ML_ACC_UnprotectMemory(void);



/** \}*/

#ifdef  __cplusplus
}
#endif //  __cplusplus

#endif // MLACC_H__
