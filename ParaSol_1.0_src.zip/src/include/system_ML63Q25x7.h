/******************************************************************************
 * @file     system_ML63Q25x7.h
 * @brief    CMSIS Device System Header File for ML63Q25x7 Device
 * @version  1.10
 * @date     25 Mar 2026
 ******************************************************************************/
/*
 * Copyright (C) 2026 ROHM Co., Ltd. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This file is based on the following Device Example of CMSIS-Core(M) Version 5.8.0.
 *   - system_ARMCM3.h
 *     Copyright (c) 2009-2019 Arm Limited. All rights reserved.
 */

#ifndef __SYSTEM_ML63Q25x7_H
#define __SYSTEM_ML63Q25x7_H

#ifdef __cplusplus
extern "C" {
#endif


/**
  \brief Exception / Interrupt Handler Function Prototype
*/
typedef void(*VECTOR_TABLE_Type)(void);

/**
  \brief System Clock Frequency (Core Clock)
*/
extern uint32_t SystemCoreClock;

/**
  \brief Setup the microcontroller system.

   Initialize the System and update the SystemCoreClock variable.
 */
extern void SystemInit (void);


/**
  \brief  Update SystemCoreClock variable.

   Updates the SystemCoreClock with current core Clock retrieved from cpu registers.
 */
extern void SystemCoreClockUpdate (void);



#ifdef __cplusplus
}
#endif

#endif


